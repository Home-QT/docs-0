#include "mywidget.h"
#include "ui_mywidget.h"

MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent), ui(new Ui::MyWidget)
{
    ui->setupUi(this);
    ui->MyLabel->setText("My first programm");
    QObject::connect(ui->MyPushButton1, SIGNAL(clicked()), this, SLOT(MyEventHandler()));
    QObject::connect(this, SIGNAL(MySignal(QString)), ui->MyLineEdit2, SLOT(setText(QString)));
    QObject::connect(this, SIGNAL(MySignal(QString)), ui->MyLabel, SLOT(setText(QString)));
}

MyWidget::~MyWidget()
{
    delete ui;
}

void MyWidget::MyEventHandler()
{
    emit MySignal(ui->MyLineEdit1->text());
}
