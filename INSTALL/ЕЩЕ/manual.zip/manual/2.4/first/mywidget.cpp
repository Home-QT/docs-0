#include "mywidget.h"
#include "ui_mywidget.h"

MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent), ui(new Ui::MyWidget)
{
    ui->setupUi(this);
    ui->MyLabel->setText("My first programm");
}

MyWidget::~MyWidget()
{
    delete ui;
}
